<?php
echo view('iyan/layout/head');
echo view('iyan/layout/header');
echo view('iyan/layout/nav');
echo view('iyan/layout/content');
echo view('iyan/layout/footer');
