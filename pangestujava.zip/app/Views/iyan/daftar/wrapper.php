<?php
echo view('iyan/daftar/header');
echo view('iyan/daftar/list');
echo view('iyan/daftar/footer');
