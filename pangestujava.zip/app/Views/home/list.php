<?php
echo view('home/home');
echo view('home/about');
echo view('home/quality');
echo view('home/skill');
// echo view('home/service');
echo view('home/portfolio');
echo view('home/kontak');
