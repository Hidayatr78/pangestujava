<?php
echo view('layout/head');
echo view('layout/nav');
echo view('layout/content');
echo view('layout/footer');
