<!-- About -->
<section id="about">
    <div class="container">
        <div class="row text-center mb-5">
            <div class="col">
                <h2>Who Am I</h2>
            </div>
        </div>
        <div class="row justify-content-center fs-5 text-center">
            <div class="col-md-5">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. A architecto autem eos molestiae modi reiciendis quia repudiandae enim totam explicabo. Omnis iure libero consectetur debitis quibusdam. Aperiam voluptatibus ea obcaecati molestiae laboriosam eius quisquam, odio qui voluptatum asperiores numquam. Provident voluptatum aliquam nulla dolores quod consequuntur repudiandae aliquid neque exercitationem.</p>
            </div>
            <div class="col-md-5">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere quod aliquid fugit obcaecati iusto corrupti unde consequatur architecto repellendus error perspiciatis, officiis labore reiciendis ratione consequuntur quae nisi nam temporibus. Molestiae nemo tenetur quaerat! Ullam est temporibus, eligendi cupiditate ab mollitia aut eveniet distinctio iusto inventore nam hic laudantium expedita?</p>
            </div>
        </div>
    </div>
</section>
<!-- End About -->