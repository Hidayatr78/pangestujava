<?php
echo view('home/home');
echo view('home/about');
echo view('home/skill');
echo view('home/project');
echo view('home/contact');
